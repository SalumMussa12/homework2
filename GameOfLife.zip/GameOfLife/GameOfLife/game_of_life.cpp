#include "game_of_life.h"
#include <cstdlib>
#include <ctime>

bool game_of_life::random_value() {
    return rand() % 2 == 0;
}

bool game_of_life::cell_taken(int i, int j) {
    if (i < 0 || i >= ROWS || j < 0 || j >= COLS) {
        return false;
    }
    return _generation[i][j];
}

game_of_life::game_of_life() {
    srand(time(NULL));
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            _generation[i][j] = random_value();
        }
    }
}

void game_of_life::next_generation() {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            int count = 0;
            if (cell_taken(i - 1, j - 1)) count++;
            if (cell_taken(i - 1, j)) count++;
            if (cell_taken(i - 1, j + 1)) count++;
            if (cell_taken(i, j - 1)) count++;
            if (cell_taken(i, j + 1)) count++;
            if (cell_taken(i + 1, j - 1)) count++;
            if (cell_taken(i + 1, j)) count++;
            if (cell_taken(i + 1, j + 1)) count++;

            if (_generation[i][j]) {
                if (count < 2 || count > 3) {
                    _next_generation[i][j] = false;
                }
                else {
                    _next_generation[i][j] = true;
                }
            }
            else {
                if (count == 3) {
                    _next_generation[i][j] = true;
                }
                else {
                    _next_generation[i][j] = false;
                }
            }
        }
    }

    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            _generation[i][j] = _next_generation[i][j];
        }
    }
}

void game_of_life::draw() {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            if (_generation[i][j]) {
                cout << "*";
            }
            else {
                cout << ".";
            }
        }
        cout << endl;
    }
    cout << endl;
}

